package com.rsa.fa.blackbox.integration.unit;

import org.junit.Test;

import com.rsa.fa.blackbox.integration.AbstractBlackBoxTestCase;
import com.rsa.fa.blackbox.integration.infra.report.Reporter.Status;

public class ReportersManagerTests extends AbstractBlackBoxTestCase{
	
	@Test
	public void testSimplePrint(){
		reporter.report("Simple message");
	}
	
	@Test()
	
	public void testFailureReport(){
//		reporter.report("Failure report", Status.FAILURE);
	}
}
