/*
 * Organization: RSA
 * Product:      Blackbox
 * Version:      1.0.1
 * Project:		 blackbox-integration-test
 */
package com.rsa.fa.blackbox.integration;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;

import com.rsa.fa.blackbox.integration.infra.report.ReportersManager;
import com.rsa.fa.blackbox.integration.infra.runner.IntegrationJUnit4ClassRunner;
import com.rsa.fa.blackbox.integration.unit.ReportersManagerTests;

/**
 * <b>Package:</b> com.rsa.fa.blackbox.integration<br/>
 * <b>Type:</b> AbstractBlackBoxTestCase<br/>
 * <b>Description:</b> <br/>
 * 
 * @author abraho <br/>
 */
@RunWith(IntegrationJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/blackbox-integration-context.xml" })
public abstract class AbstractBlackBoxTestCase {
	
	protected ReportersManager reporter = ReportersManager.getInstance();
	
	protected void sleep(long milliToSleep){
		try {
			Thread.sleep(milliToSleep);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
