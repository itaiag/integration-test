package com.rsa.fa.blackbox.integration.unit;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.rsa.fa.blackbox.integration.AbstractBlackBoxTestCase;
import com.rsa.fa.blackbox.integration.systemModule.database.DatabaseSystemModule;

public class DatabaseSystemModuleTests extends AbstractBlackBoxTestCase {

	@Autowired
	private DatabaseSystemModule db;

	@Test
	public void testNumberOfRows() {
		reporter.report("About to test database");
		Assert.assertEquals(3, db.countRowsInTable("BLACKBOX.ATTACK_TYPE"));
	}

}
