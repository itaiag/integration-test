package com.rsa.fa.blackbox.integration.systemModule;

import com.rsa.fa.blackbox.integration.infra.report.ReportersManager;

public abstract class AbstractSystemModule {
	
	protected ReportersManager reporter = ReportersManager.getInstance();  
	
}
