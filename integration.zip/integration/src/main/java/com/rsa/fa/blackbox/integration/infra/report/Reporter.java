package com.rsa.fa.blackbox.integration.infra.report;

public interface Reporter {
	public enum Status {
		SUCCESS, FAILURE
	}

	public void report(String title, String message, Status status);

}
